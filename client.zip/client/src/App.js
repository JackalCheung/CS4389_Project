import React, { Component } from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Home from "./views/Home.js";
import Candidates from "./views/Candidates.js";
import Voting from "./views/Voting.js";
import Admin from "./views/Admin.js";
import Cover from "./views/Cover.js";
import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import "./App.css";

import "./assets/css/normalize.min.css";
import "./assets/css/bootstrap.min.css";
import "./assets/css/cs-skin-elastic.css";
import "./assets/css/style.css";

class App extends Component {

    componentDidMount = async () => {
        try {
            
        } catch (error) {
            
        }
    };

    render() {
        return (
            <Router forceRefresh={true}>
                <Cover />
            </Router>
        );
    }
}

export default App;
