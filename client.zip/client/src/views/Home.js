import React, { Component } from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Election from "../contracts/Election.json";
import Callback from "../contracts/Callback.json";
import ElectionOracle from "../contracts/ElectionOracle.json";
import getWeb3 from "../utils/getWeb3";

import "../App.css";

import "bootstrap";
import "../assets/css/normalize.min.css";
import "../assets/css/bootstrap.min.css";
import "../assets/css/cs-skin-elastic.css";
import "../assets/css/style.css";

var ODCount = 0;
var AppSelf;

var candidates = {
    "1" : "Unnat",
    "2" : "Jackal", 
    "3" : "Dennis",
    "4" : "Peter",
    "5" : "Mary"
}

class Home extends Component {
    state = {
        web3: null, account: null, contract: null, candidates: []
        , fromBlock: 0, oracleContract: null, candidateName: null
    };
    componentDidMount = async () => {
        try {
            var Self = this;
            const web3 = await getWeb3();
            // alert(JSON.stringify(web3));
            const accounts = await web3.eth.getAccounts();
            // Get the contract instance.
            // const networkId = await web3.eth.net.getId();
            // const deployedNetwork = Election.networks[networkId];
            const instance = new web3.eth.Contract(
                Election.abi
            );
            instance.options.address = '0xDC6f25793F7012049ace3E82ab0188B07CF2a5c2';
            const oracleInstance = new web3.eth.Contract(
                ElectionOracle.abi
            );
			oracleInstance.options.address = '0x6C5953Abb67D936682fEcdDCECA94af8a86a3472';
            this.setState({ web3, account: accounts[0], contract: instance, oracleContract: oracleInstance }, ()=>{
                var x = setTimeout(Self.listToOracle, 2000);
                Self.setState({listToOracleTimeout: x})
            });
            
            instance.methods.candidatesCount().call().then(function(res){
                console.log(res);
                if (res){
                    for (var i = 1; i <= res ; i++) {
                        instance.methods.candidates(i).call().then(function(candidate) {
                            var id = candidate[0];
                            var voteCount = candidate[1];
                            let tempObject = { id , voteCount };
                            // Render candidate Result
                            // var candidateTemplate = "<tr><th>" + id + "</th><td>" + name + "</td><td>" + voteCount + "</td></tr>"
                            Self.setState(prevState => ({
                                candidates: [...prevState.candidates, tempObject]
                            }));
                        });
                    }
                } 
            });
            instance.getPastEvents('periodControl', {fromBlock:0, toBlock: 'latest'}).then((res)=>{
                console.log(res);
                if (res.length > 0){
                    let lastEvent = res[res.length - 1];
                    let status = lastEvent.returnValues.status;
                    Self.setState({started: status});
                }
            })
            // .on('data', function(event) {
            //     if (event.returnValues.validity){
            //         instance.methods.callbackVoteRecord(event.returnValues.validity).send({ from: accounts[0] , gas: 500000 }, (err,trans) => {
            //             console.log("Checked for Vote");
            //         })
            //     }
            //     // console.log(event);
            // })
            // .on('error', console.error);


            // instance.events.voteValidation({
            //     fromBlock: 0, toBlock: 'latest'
            // }) .on('data', function (event) {
            //     if (event.returnValues.validity === true){
            //         console.log(event);
            //     }
            // }) .on('error', console.error);


        } catch (error) {
            // Catch any errors for any of the above operations.
            alert(
                `Failed to load web3, accounts, or contract. Check console for details.`,
            );
            console.error(error);
        }
    };
    addCandidates = async () => {
        var AppSelf = this;
        const { account, contract } = this.state;
        // console.log("Added");
        // console.log(this.state.contract.candidates);
        contract.methods.addCandidate().send({ from: account, gas: 500000 }, (err,trans) => {
            console.log("Added Unnat");
            console.log(trans);
            // AppSelf.getCandidates();
        });
        contract.methods.addCandidate().send({ from: account, gas: 500000 }, (err,trans) => {
            console.log("Added Jackal");
            console.log(trans);
            // AppSelf.getCandidates();
        });
        // console.log(this.state.contract.candidates);
    }
    getCandidates = async () => {
        // console.log("Checking Cands!""
        // var x = setTimeout(this.getCandidates, 2000);
        // this.setState({getCandidateTimeout: x});
        var AppSelf = this;
        
    }
    vote = async (event) =>{
        event.preventDefault();
        var choice = 1;
        var AppSelf = this;
        const { account, contract } = this.state;
        contract.methods.vote(choice).send({ from: account, gas: 500000 })
        .on('reciept',console.log);
    }
    listToOracle = async () =>{
        var x = setTimeout(this.listToOracle, 2000);
        const { oracleContract } = this.state;
        var AppSelf = this;
        // var b = this.state.fromBlock;
        oracleContract.events.voteValidation({
                fromBlock: 0, toBlock: 'latest'
            }) .on('data', function (event) {
                console.log(event.blockNumber + "=" + ODCount)
                // AppSelf.setState({fromBlock : event.blockNumber}); 
                if (event.blockNumber <= ODCount) return;
                ODCount = event.blockNumber;
                if (event.returnValues.validity === true){
                    AppSelf.processOracleData(event.returnValues.me ,event.returnValues.validity, event.returnValues.candidateID);
                }
            }) .on('error', console.error);
        
    };

    processOracleData = (electionCon, vote, candidateID) => {
        const { account } = this.state;
        if (vote){
            var contractToCall = new this.state.web3.eth.Contract(
                Callback.abi,
                electionCon
            )
            contractToCall.methods.callbackVoteRecord(candidates[candidateID]).send({ from: account, gas: 500000 }, function(err, trans){
                 console.log(trans);
             });
        }
    }
    // monitorVote = async () =>{
    //     const b = this.state.fromBlock;
    //     var AppSelf = this;
    //     this.state.contract.events.voteValidation({
    //         fromBlock: b, toBlock: 'latest'
    //     })
    //     .on('data', function (event) {
    //         // event format is ToOracle(address me, string data)
    //         if (event.blockNumber <= ODCount) return;
    //         ODCount = event.blockNumber;
    //         AppSelf.state.contract.methods.VoteValidationCallback(event.status, candidate[choice]).send({ from: account, gas: 500000 }, (err,trans) => {
    //             console.log("Checked for Vote");
    //             console.log(trans);
    //         })
    //     })
    //     .on('error', console.error);
    //     this.state.contract.events.voteValidation({
    //         fromBlock: b, toBlock: 'latest'
    //     })
    //     .on('data', function (event) {
    //         // event format is ToOracle(address me, string data)
    //         if (event.blockNumber <= ODCount) return;
    //         ODCount = event.blockNumber;
    //         AppSelf.state.contract.methods.VoteValidationCallback(event.status, candidate[choice]).send({ from: account, gas: 500000 }, (err,trans) => {
    //             console.log("Checked for Vote");
    //             console.log(trans);
    //         })
    //     })
    //     .on('error', console.error);
    // };
        

    render() {
        if (!this.state.web3) {
            return <div>Loading Web3, accounts, and contract...</div>;
        }
        return (
			<div>
				<div class="breadcrumbs">
					<div class="breadcrumbs-inner">
						<div class="row m-0">
							<div class="col-sm-12">
								<div class="page-header">
									<div class="page-title">
										<div class="float-left">
											<h1>SU Election</h1>
										</div>
                                        <div class="float-right" style={{"paddingTop":"10px"}}>
                                        {this.state.started ? 
                                        <span class="badge badge-success">Starting</span>
                                        :
                                        <span></span>
                                        }
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="card-body">
					<div class="content">
						<div class="animated fadeIn">
							<div class="row">
								<div class="col-xl-12">
									<div class="modal fade" id="largeModal" tabindex="-1" role="dialog" aria-labelledby="largeModalLabel" aria-hidden="true">
										<div class="modal-dialog modal-lg" role="document">
											<div class="modal-content">
												<div class="modal-body">
													<div class="card-body card-block">
														<form action="#" method="post" enctype="multipart/form-data" class="form-horizontal">
															<div class="row form-group">
																<div class="col col-md-3"><label class=" form-control-label">Election Name:</label></div>
																<div class="col-12 col-md-9">
																	<p class="form-control-static">SU Election</p>
																</div>
															</div>
															<div class="row form-group">
																<div class="col col-md-3"><label for="text-input" class=" form-control-label">Cabinet Name:</label></div>
																<div class="col-12 col-md-9"><input type="text" id="text-input" name="text-input" placeholder="Name" class="form-control" /></div>
															</div>
															<div class="row form-group">
																<div class="col col-md-3"><label for="textarea-input" class=" form-control-label">Short Text Description:</label></div>
																<div class="col-12 col-md-9"><textarea name="textarea-input" id="textarea-input" rows="9" placeholder="Description" class="form-control"></textarea></div>
															</div>
															<div class="row form-group">
																<div class="col col-md-3"><label for="file-input" class=" form-control-label">Image:</label></div>
																<div class="col-12 col-md-9"><input type="file" id="file-input" name="file-input" class="form-control-file" /></div>
															</div>
														</form>
													</div>
												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
													<button type="button" class="btn btn-primary">Confirm</button>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="row">
                                {this.state.candidates && this.state.candidates.map((info, i) => 
									<div class="col-md-6">
										<div class="feed-box text-center">
											<section class="card">
												<div class="card-body">
                                                    <h4 class="mb-3 text-right">#{i+1} </h4>
                                                    <h2>{ candidates[info.id] }</h2>
                                                    <br />
												</div>
                                                {this.state.started ? 
                                                <button type="button" class="btn btn-primary" onClick={this.vote}>Vote</button>
                                                :
                                                <button>Cannot Vote</button>
                                                }
											</section>
										</div>
									</div>
								)}
							</div>
						</div>
					</div>

					<div class="clearfix"></div>

					<footer class="site-footer">
						<div class="footer-inner bg-white">
							<div class="row">
								<div class="col-sm-6">
									Copyright &copy; 2018 Ela Admin
								</div>
								<div class="col-sm-6 text-right">
									Designed by <a href="https://colorlib.com">Colorlib</a>
								</div>
							</div>
						</div>
					</footer>
				</div>
			</div>
        );
    }
}

export default Home;
