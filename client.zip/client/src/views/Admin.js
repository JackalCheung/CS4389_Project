import React, { Component } from "react";
import Election from "../contracts/Election.json";
import ElectionOracle from "../contracts/ElectionOracle.json";
import Callback from "../contracts/Callback.json";
import getWeb3 from "../utils/getWeb3";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";

import "../App.css";

import "bootstrap";
import "../assets/css/normalize.min.css";
import "../assets/css/bootstrap.min.css";
import "../assets/css/cs-skin-elastic.css";
import "../assets/css/style.css";

var WinnerID = [];
var WinnerNames = [];
var WinnerVotes = [];
var VoteTo = [];
var VotingTimestamps = [];
const ODCount = 0;

var candidates = {
    "1" : "Unnat",
    "2" : "Jackal", 
    "3" : "Dennis",
    "4" : "Peter",
    "5" : "Mary"
}

class Admin extends Component {
    
    state = {
        web3: null, account: null, contract: null, candidates: []
        , fromBlock: 0, oracleContract: null
    };
    componentDidMount = async () => {
        try {
            var Self = this;
            const web3 = await getWeb3();
            // alert(JSON.stringify(web3));
            const accounts = await web3.eth.getAccounts();
            // Get the contract instance.
            // const networkId = await web3.eth.net.getId();
            // const deployedNetwork = Election.networks[networkId];
            const instance = new web3.eth.Contract(
                Election.abi
            );
            instance.options.address = '0xDC6f25793F7012049ace3E82ab0188B07CF2a5c2';
            const oracleInstance = new web3.eth.Contract(
                ElectionOracle.abi
            );
			oracleInstance.options.address = '0x6C5953Abb67D936682fEcdDCECA94af8a86a3472';
			this.setState({ web3, account: accounts[0], contract: instance, oracleContract: oracleInstance });
            instance.getPastEvents("voteValidation", { fromBlock: 0, toBlock: 'latest' }, (err, res) => { 
                for (var i=0; i< res.length; i++){
                    this.setState(prevState => ({
                        votes: [...prevState.votes , res.returnValues]
                    }))
                    ODCount = res.blockNumber;
                }
             });
            instance.methods.candidatesCount().call().then(function(res){ 
                for (var i = 1; i <= res.toNumber() ; i++) {
                    instance.methods.candidates(i).call().then(function(candidate) {
                        var id = candidate[0].toNumber();
                        var voteCount = candidate[1].toNumber();
                        let tempObject = { id , voteCount };
                        // Render candidate Result
                        // var candidateTemplate = "<tr><th>" + id + "</th><td>" + name + "</td><td>" + voteCount + "</td></tr>"
                        Self.setState(prevState => ({
                            candidates: [...prevState.candidates, tempObject]
                        }));
                    });
                }
            });
        } catch (error) {
            // Catch any errors for any of the above operations.
            alert(
                `Failed to load web3, accounts, or contract. Check console for details.`,
            );
            console.error(error);
        }
    };

    addCandidates = async (_name ) => {
        var AppSelf = this;
        const { account, contract } = this.state;
        AppSelf.state.candidates.push(_name);
        contract.methods.addCandidate().send({ from: account, gas: 500000 }, (err, trans) => {
            console.log("Added " + _name);
        });
        // console.log(this.state.contract.candidates);
    }
    start = () => {
        
        const { account, contract } = this.state;
        contract.methods.startElection().send({ from: account, gas: 500000 }, (err, trans) => {
            console.log("Started Election ");
        });
    }
    end = () => {
        const { account, contract } = this.state;
        contract.methods.endElection().send({ from: account, gas: 500000 }, (err, trans) => {
            console.log("Ended Election ");
            contract.methods.finalResult().send({ from: account, gas: 500000 }, (err, trans) => {
                console.log("Found Result");
            });
        });
    }

    listToOracle = async () => {
        var AppSelf = this;
        var x = setTimeout(this.listToOracle, 2000);
        console.log("Admin listen");
        AppSelf.state.oracleContract.events.ElectionWinner({
            fromBlock: ODCount, toBlock: 'latest'
        }).on('data', function (event) {
            console.log("Process winner data");
            WinnerID.push(event.returnValues.winnerID);
            WinnerNames.push(AppSelf.processOracleData(event.returnValues.me, event.returnValues.winnerID));
            WinnerVotes.push(event.returnValues.voteReceived);
            AppSelf.sendDataToBlockchain(event.returnValues.me, event.returnValues.winnerID);
            ODCount = event.blockNumber;
        }).on('error', console.error);

    };

    processOracleData(callback_address, _winnerID) {
        var AppSelf = this;
        console.log('in processOracleData:' + _winnerID);
        // can process locally or call an other service to handle the data
        return AppSelf.state.candidates[_winnerID];
    }

    sendDataToBlockchain = async (address, _winnerID) => {
        var AppSelf = this;
        if (!address) return;

        console.log('in sendDataToBlockchain:' + address);
        const contractToCall = new AppSelf.state.web3.eth.Contract(
            Callback.abi,
            address
            );
            
        contractToCall.methods.callbackWinnerRecord(_winnerID).send(
            { from: AppSelf.state.accounts[0], gas: 80000 });
        return;
    }

    getVoteEvent = async () => {
        var AppSelf = this;
        AppSelf.state.contract.getPastEvents("voteValidation", { fromBlock: 0, toBlock: 'latest' },
            (error, result) => { })
            .then((events) => {
                if (events.length > 0) {
                    for (var i = 0; i < events.length; i++) {
                        //This is an asynchronous call
                        var block = AppSelf.state.web3.eth.getBlock(events[i].blockNumber);
                        block.then(function (response) {
                            VotingTimestamps.push(AppSelf.timeConverter(response.timestamp));
                        });
                        VoteTo.push(events[i].returnValues._candidateName);
                    }
                }
            });
    }

    timeConverter(UNIX_timestamp) {
        var a = new Date(UNIX_timestamp * 1000);
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        var year = a.getFullYear();
        var month = months[a.getMonth()];
        var date = a.getDate();
        var hour = a.getHours();
        var min = a.getMinutes();
        var sec = a.getSeconds();
        var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec;
        return time;
    }
        
    render() {
        if (!this.state.web3) {
            return <div>Loading Web3, accounts, and contract...</div>;
        }
        return (
            <div>
                <div class="breadcrumbs">
                    <div class="breadcrumbs-inner">
                        <div class="row m-0">
                            <div class="col-sm-12">
                                <div class="page-header">
                                    <div class="page-title">
                                        <div class="float-left">
                                            <h1>SU Election</h1>
                                        </div>
                                        
                                        <span class="float-left" style={{'paddingTop':'10px', 'paddingLeft':'10px'}}>
                                            <button type="button" class="btn btn-success btn-sm" onClick={this.start}>
                                                Start
                                            </button>
                                            <button type="button" class="btn btn-danger btn-sm" onClick={this.end}>
                                                End
                                            </button>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="content">
                        <div class="card">
                            <div class="card-header">
                                <h4>Current Voting Result</h4>
                            </div>
                            <div class="card-body">
                                <table>
                                    <tbody>
                                    <tr>
                                        <th> Candidate ID</th>
                                        <th> Candidate Name</th>
                                        <th> Votes </th>
                                    </tr>
                                    {this.state.candidates && this.state.candidates.map((info, i) => 
                                        <tr>
                                            <td> { i + 1 } </td>
                                            <td> { candidates[info.id] } </td>
                                            <td> { info.voteCount } </td>
                                        </tr>
                                    )} 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <div class="animated fadeIn">
                            <div class="row">
                                <div class="card-body">
                                    <span style={{'float':'right'}}>
                                        <button type="button" class="btn btn-primary mb-1" data-toggle="modal" data-target="#largeModal" onClick={this.addCandidates}>
                                            Add New Cabinet
                                        </button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="clearfix"></div>

                    <footer class="site-footer">
                        <div class="footer-inner bg-white">
                            <div class="row">
                                <div class="col-sm-6">
                                    Copyright &copy; 2018 Ela Admin
                                </div>
                                <div class="col-sm-6 text-right">
                                    Designed by <a href="https://colorlib.com">Colorlib</a>
                                </div>
                            </div>
                        </div>
                    </footer>
                </div>
            </div>
        );
    }
}

export default Admin;