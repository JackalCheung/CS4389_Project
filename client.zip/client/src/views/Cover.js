import React, { Component } from "react";
import Election from "../contracts/Election.json";
import ElectionOracle from "../contracts/ElectionOracle.json";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import getWeb3 from "../utils/getWeb3";

import "../App.css";

import "../assets/css/normalize.min.css";
import "../assets/css/bootstrap.min.css";
import "../assets/css/cs-skin-elastic.css";
import "../assets/css/style.css";

import Home from "./Home.js";
import Candidates from "./Candidates.js";
import Admin from "./Admin.js";

var admin = "0xc81736dDD673e4F14368A3486fE78772037a14CB";

class Cover extends Component {
	
	state = {
        web3: null, account: null, contract: null, candidates: []
        , fromBlock: 0, oracleContract: null, candidateName: null
	};

	componentDidMount = async () => {
		
        try {
            // Self = this;
            const web3 = await getWeb3();
            // alert(JSON.stringify(web3));
            const accounts = await web3.eth.getAccounts();
            // Get the contract instance.
            // const networkId = await web3.eth.net.getId();
            // const deployedNetwork = Election.networks[networkId];
            const instance = new web3.eth.Contract(
                Election.abi
            );
            instance.options.address = '0xDC6f25793F7012049ace3E82ab0188B07CF2a5c2';
            const oracleInstance = new web3.eth.Contract(
                ElectionOracle.abi
            );
			oracleInstance.options.address = '0x6C5953Abb67D936682fEcdDCECA94af8a86a3472';
			this.setState({ web3, account: accounts[0], contract: instance, oracleContract: oracleInstance });
            instance.getPastEvents("voteValidation", { fromBlock: 0, toBlock: 'latest' }, (err, res) => { console.log(res) });
        } catch (error) {
            // Catch any errors for any of the above operations.
            alert(
                `Failed to load web3, accounts, or contract. Check console for details.`,
            );
			console.error(error);
		}
		
    };

    render() {
		//var component = (this.props.isAdmin)? 	<Route exact path="/" component={Admin} /> :
		//											<Route exact path="/" component={Home} />;
		console.log(admin);
		console.log(String(this.state.account));
        return (
            <div>
				<aside id="left-panel" class="left-panel">
					<nav class="navbar navbar-expand-sm navbar-default">
						<div id="main-menu" class="main-menu collapse navbar-collapse">
							<ul class="nav navbar-nav">
								<li class="active">
									<a style={{'textDecoration': 'none'}}><i class="menu-icon fa fa-laptop"></i><Link to="/admin">Admin</Link></a>
									<a style={{'textDecoration': 'none'}}><i class="menu-icon fa fa-laptop"></i><Link to="/">Users</Link></a>
								</li>
							</ul>
						</div>
					</nav>
				</aside>
				<div id="right-panel" class="right-panel">
					<header id="header" class="header">
						<div class="top-left">
							<div class="navbar-header">
								<Link to="/">
									<a class="navbar-brand"><img src={require("../images/cityu_m.png")} alt="Logo" height="40" /></a>
									<a class="navbar-brand hidden"><img src={require("../images/logo2.png")} alt="Logo" /></a>
								</Link>
							</div>
						</div>
					</header>
					<Route path="/candidates" component={Candidates} />
					<Route exact path="/admin" component={Admin} />
					<Route exact path="/" component={Home} />
				</div>
			</div>
        );
    }
}

export default Cover;
