import React, { Component } from "react";
// import { BrowserRouter as Router, Route, Link } from "react-router-dom";

import "../App.css";

class Candidates extends Component {
    state = { user: null };

    componentDidMount = async () => {
        try {

        } catch (error) {

        }
    };

    runExample = async () => {
        
    };

    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default Candidates;
